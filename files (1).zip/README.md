# Credit Scoring Model

**Objective:** Predict an individual's creditworthiness from past financial data.
**Approach:** Classification with Logistic Regression, Decision Tree, and Random Forest.

## Quick start
```bash
pip install -r requirements.txt
python credit_scoring.py                 # synthetic data
python credit_scoring.py --data my.csv   # your own data (target column: creditworthy, 1 = good, 0 = bad)
python predict.py                        # score a sample applicant
```

## What it does
1. **Data** - generates a synthetic dataset (income, debts, payment history, utilization, inquiries...) or loads your CSV.
2. **Feature engineering** - debt-to-income, loan-to-income, log income, total late payments, payment-history score, average account age, high-utilization flag, debt per credit line.
3. **Modeling** - median imputation (+ scaling for LR) in sklearn Pipelines; `class_weight="balanced"`.
4. **Evaluation** - Precision, Recall, F1-Score, ROC-AUC on a stratified hold-out set, plus 5-fold CV ROC-AUC.

## Outputs (`outputs/`)
- `model_comparison.csv` - metrics table
- `roc_curves.png`, `confusion_matrix.png`, `feature_importance.png`
- `best_model.joblib` - best model by ROC-AUC
- `synthetic_credit_data.csv`

## Using real data
Try the *Give Me Some Credit* or *German Credit* datasets. Rename columns to match, or edit `engineer_features()`.
Note: on real data, tune hyperparameters (GridSearchCV) and consider SMOTE if classes are very imbalanced.
