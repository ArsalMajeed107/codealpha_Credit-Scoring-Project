"""Score a new applicant with the trained model."""
import joblib
import pandas as pd
from credit_scoring import engineer_features

bundle = joblib.load("outputs/best_model.joblib")

applicant = pd.DataFrame([{
    "age": 35, "income": 65000, "employment_years": 8, "credit_history_years": 10,
    "num_credit_lines": 5, "total_debt": 18000, "loan_amount": 20000,
    "credit_utilization": 0.35, "late_payments_30d": 0, "late_payments_90d": 0,
    "credit_inquiries_6m": 1, "has_mortgage": 1,
}])

X = engineer_features(applicant)[bundle["features"]]
p = bundle["model"].predict_proba(X)[0, 1]
print(f"Probability creditworthy: {p:.1%} -> {'APPROVE' if p >= 0.5 else 'REVIEW / DECLINE'}")
